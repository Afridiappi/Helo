// Resume Builder - Main JavaScript File
// Comprehensive functionality for AI-powered resume builder

class ResumeBuilder {
    constructor() {
        this.currentTemplate = 'professional';
        this.resumeData = {
            personal: {},
            experience: [],
            education: [],
            skills: [],
            summary: ''
        };
        this.aiFeatures = {
            contentGenerator: true,
            keywordOptimizer: true,
            atsChecker: true,
            realTimeAnalysis: true
        };
        this.templates = this.initializeTemplates();
        this.init();
    }

    init() {
        this.setupEventListeners();
        this.initializeAnimations();
        this.loadTemplateData();
        this.setupAIFeatures();
    }

    // Template Management
    initializeTemplates() {
        return {
            professional: {
                name: 'Professional',
                category: 'corporate',
                colors: ['#2C3E50', '#16A085', '#FEFEFE'],
                fonts: ['Playfair Display', 'Inter'],
                layout: 'traditional'
            },
            modern: {
                name: 'Modern',
                category: 'contemporary',
                colors: ['#6C5CE7', '#00B894', '#FEFEFE'],
                fonts: ['Inter', 'JetBrains Mono'],
                layout: 'two-column'
            },
            creative: {
                name: 'Creative',
                category: 'design',
                colors: ['#E84393', '#0984E3', '#FEFEFE'],
                fonts: ['Playfair Display', 'Inter'],
                layout: 'asymmetric'
            },
            minimal: {
                name: 'Minimal',
                category: 'simple',
                colors: ['#2D3436', '#636E72', '#FEFEFE'],
                fonts: ['Inter', 'Inter'],
                layout: 'clean'
            },
            ats: {
                name: 'ATS-Friendly',
                category: 'optimized',
                colors: ['#2C3E50', '#34495E', '#FEFEFE'],
                fonts: ['Arial', 'Helvetica'],
                layout: 'single-column'
            }
        };
    }

    // AI Content Generation
    generateContent(section, input) {
        const contentLibrary = {
            experience: [
                "Led cross-functional team of {number} members to achieve {result}",
                "Implemented {technology} resulting in {percentage}% improvement in {metric}",
                "Managed {budget} budget while delivering {outcome} ahead of schedule",
                "Developed {system} that processed {volume} transactions daily",
                "Collaborated with {departments} to streamline {process} by {percentage}%"
            ],
            skills: [
                "Project Management", "Team Leadership", "Strategic Planning",
                "Data Analysis", "Communication", "Problem Solving",
                "Technical Writing", "Quality Assurance", "Process Improvement"
            ],
            summary: [
                "Results-driven {role} with {years} years of experience in {industry}",
                "Proven track record of {achievement} through {skill} and {methodology}",
                "Passionate about {field} with expertise in {specialization}"
            ]
        };

        if (contentLibrary[section]) {
            const templates = contentLibrary[section];
            return templates[Math.floor(Math.random() * templates.length)];
        }
        return "Generated content will appear here...";
    }

    // Real-time Analysis
    analyzeContent(content) {
        const analysis = {
            score: 0,
            suggestions: [],
            keywords: [],
            atsFriendly: true
        };

        // Word count analysis
        const wordCount = content.split(' ').length;
        if (wordCount < 50) {
            analysis.suggestions.push("Consider adding more detail to strengthen your content");
        }

        // Action verb check
        const actionVerbs = ['led', 'managed', 'developed', 'implemented', 'achieved', 'improved'];
        const hasActionVerb = actionVerbs.some(verb => content.toLowerCase().includes(verb));
        if (!hasActionVerb) {
            analysis.suggestions.push("Start bullet points with strong action verbs");
        }

        // Quantification check
        const hasNumbers = /\d/.test(content);
        if (!hasNumbers) {
            analysis.suggestions.push("Add quantifiable achievements to demonstrate impact");
        }

        // Calculate score
        analysis.score = Math.min(100, (hasActionVerb ? 30 : 0) + (hasNumbers ? 30 : 0) + Math.min(40, wordCount / 2));

        return analysis;
    }

    // PDF Generation
    async generatePDF() {
        try {
            const { PDFDocument, rgb } = await import('https://cdn.skypack.dev/pdf-lib');
            const pdfDoc = await PDFDocument.create();
            const page = pdfDoc.addPage([595.28, 841.89]); // A4 size

            // Add content to PDF
            const { personal, experience, education, skills } = this.resumeData;
            
            // Header
            page.drawText(`${personal.firstName || 'Your'} ${personal.lastName || 'Name'}`, {
                x: 50,
                y: 750,
                size: 24,
                color: rgb(0.2, 0.4, 0.8)
            });

            // Contact info
            if (personal.email) {
                page.drawText(personal.email, { x: 50, y: 720, size: 12, color: rgb(0.3, 0.3, 0.3) });
            }

            // Experience section
            page.drawText('Experience', { x: 50, y: 680, size: 16, color: rgb(0.2, 0.4, 0.8) });
            let yPos = 660;
            experience.forEach((exp, index) => {
                page.drawText(`${exp.title || 'Position'} at ${exp.company || 'Company'}`, {
                    x: 50, y: yPos, size: 12, color: rgb(0.2, 0.2, 0.2)
                });
                yPos -= 20;
            });

            const pdfBytes = await pdfDoc.save();
            const blob = new Blob([pdfBytes], { type: 'application/pdf' });
            const url = URL.createObjectURL(blob);
            
            const a = document.createElement('a');
            a.href = url;
            a.download = 'my-resume.pdf';
            a.click();
            URL.revokeObjectURL(url);

            return true;
        } catch (error) {
            console.error('PDF generation failed:', error);
            return false;
        }
    }

    // Template Switching
    switchTemplate(templateId) {
        if (this.templates[templateId]) {
            this.currentTemplate = templateId;
            this.updatePreview();
            this.saveToLocalStorage();
        }
    }

    // Real-time Preview Update
    updatePreview() {
        const previewContainer = document.getElementById('resume-preview');
        if (!previewContainer) return;

        const template = this.templates[this.currentTemplate];
        const { personal, experience, education, skills, summary } = this.resumeData;

        previewContainer.innerHTML = `
            <div class="resume-preview ${template.layout}" style="
                background: ${template.colors[2]};
                color: ${template.colors[0]};
                font-family: ${template.fonts[0]};
                padding: 40px;
                border-radius: 8px;
                box-shadow: 0 4px 20px rgba(0,0,0,0.1);
            ">
                <div class="resume-header" style="
                    border-bottom: 3px solid ${template.colors[1]};
                    padding-bottom: 20px;
                    margin-bottom: 30px;
                ">
                    <h1 style="
                        font-size: 32px;
                        margin: 0;
                        color: ${template.colors[0]};
                    ">${personal.firstName || 'Your'} ${personal.lastName || 'Name'}</h1>
                    <p style="
                        font-size: 16px;
                        color: ${template.colors[1]};
                        margin: 10px 0 0 0;
                    ">${personal.title || 'Professional Title'}</p>
                </div>
                
                <div class="resume-summary">
                    <h2 style="color: ${template.colors[0]}; font-size: 20px;">Professional Summary</h2>
                    <p>${summary || 'Your professional summary will appear here...'}</p>
                </div>
                
                <div class="resume-experience">
                    <h2 style="color: ${template.colors[0]}; font-size: 20px;">Experience</h2>
                    ${experience.map(exp => `
                        <div class="experience-item" style="margin-bottom: 20px;">
                            <h3 style="margin: 0; color: ${template.colors[0]};">${exp.title || 'Position'}</h3>
                            <p style="margin: 5px 0; color: ${template.colors[1]};">${exp.company || 'Company'} | ${exp.dates || 'Dates'}</p>
                            <p style="margin: 0;">${exp.description || 'Job description...'}</p>
                        </div>
                    `).join('')}
                </div>
                
                <div class="resume-skills">
                    <h2 style="color: ${template.colors[0]}; font-size: 20px;">Skills</h2>
                    <div style="display: flex; flex-wrap: wrap; gap: 10px;">
                        ${skills.map(skill => `
                            <span style="
                                background: ${template.colors[1]};
                                color: white;
                                padding: 5px 15px;
                                border-radius: 20px;
                                font-size: 14px;
                            ">${skill}</span>
                        `).join('')}
                    </div>
                </div>
            </div>
        `;
    }

    // Local Storage Management
    saveToLocalStorage() {
        const data = {
            currentTemplate: this.currentTemplate,
            resumeData: this.resumeData,
            timestamp: Date.now()
        };
        localStorage.setItem('resumeBuilderData', JSON.stringify(data));
    }

    loadFromLocalStorage() {
        const saved = localStorage.getItem('resumeBuilderData');
        if (saved) {
            try {
                const data = JSON.parse(saved);
                this.currentTemplate = data.currentTemplate || 'professional';
                this.resumeData = { ...this.resumeData, ...data.resumeData };
                this.updatePreview();
            } catch (error) {
                console.error('Failed to load saved data:', error);
            }
        }
    }

    // Event Listeners
    setupEventListeners() {
        // Template selection
        document.addEventListener('click', (e) => {
            if (e.target.matches('.template-card')) {
                const templateId = e.target.dataset.template;
                this.switchTemplate(templateId);
            }
        });

        // Form inputs
        document.addEventListener('input', (e) => {
            if (e.target.matches('.resume-input')) {
                const field = e.target.dataset.field;
                const value = e.target.value;
                this.updateResumeData(field, value);
            }
        });

        // Export buttons
        document.addEventListener('click', (e) => {
            if (e.target.matches('.export-pdf')) {
                this.generatePDF();
            }
            if (e.target.matches('.export-phone')) {
                this.exportForPhone();
            }
            if (e.target.matches('.export-cloud')) {
                this.saveToCloud();
            }
        });

        // AI features
        document.addEventListener('click', (e) => {
            if (e.target.matches('.ai-generate')) {
                const section = e.target.dataset.section;
                this.generateAIContent(section);
            }
        });
    }

    updateResumeData(field, value) {
        const fields = field.split('.');
        if (fields.length === 2) {
            if (!this.resumeData[fields[0]]) {
                this.resumeData[fields[0]] = {};
            }
            this.resumeData[fields[0]][fields[1]] = value;
        } else {
            this.resumeData[field] = value;
        }
        this.updatePreview();
        this.saveToLocalStorage();
    }

    // AI Content Generation
    generateAIContent(section) {
        const input = document.querySelector(`[data-field="${section}"]`)?.value || '';
        const generated = this.generateContent(section, input);
        
        // Update the input field with generated content
        const inputField = document.querySelector(`[data-field="${section}"]`);
        if (inputField) {
            inputField.value = generated;
            this.updateResumeData(section, generated);
        }

        // Show success message
        this.showNotification('AI content generated successfully!', 'success');
    }

    // Export Functions
    exportForPhone() {
        // Generate mobile-optimized version
        this.showNotification('Mobile version exported!', 'success');
    }

    saveToCloud() {
        // Simulate cloud save
        this.showNotification('Saved to cloud storage!', 'success');
    }

    // Utility Functions
    showNotification(message, type = 'info') {
        const notification = document.createElement('div');
        notification.className = `notification ${type}`;
        notification.textContent = message;
        notification.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            background: ${type === 'success' ? '#16A085' : '#3498DB'};
            color: white;
            padding: 15px 20px;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
            z-index: 1000;
            animation: slideIn 0.3s ease;
        `;
        
        document.body.appendChild(notification);
        
        setTimeout(() => {
            notification.remove();
        }, 3000);
    }

    // Animations
    initializeAnimations() {
        // Initialize scroll animations
        if (typeof anime !== 'undefined') {
            anime({
                targets: '.fade-in',
                opacity: [0, 1],
                translateY: [20, 0],
                duration: 800,
                delay: anime.stagger(100),
                easing: 'easeOutQuart'
            });
        }

        // Initialize typewriter effect
        if (typeof Typed !== 'undefined') {
            new Typed('#typed-text', {
                strings: ['Professional Resumes', 'AI-Powered Content', 'Career Success'],
                typeSpeed: 100,
                backSpeed: 50,
                backDelay: 2000,
                loop: true
            });
        }
    }

    // AI Features Setup
    setupAIFeatures() {
        // Real-time content analysis
        document.addEventListener('input', (e) => {
            if (e.target.matches('.analyze-content')) {
                const analysis = this.analyzeContent(e.target.value);
                this.updateAnalysisDisplay(analysis);
            }
        });
    }

    updateAnalysisDisplay(analysis) {
        const scoreElement = document.getElementById('analysis-score');
        const suggestionsElement = document.getElementById('analysis-suggestions');
        
        if (scoreElement) {
            scoreElement.textContent = `Score: ${analysis.score}/100`;
            scoreElement.style.color = analysis.score > 70 ? '#16A085' : analysis.score > 40 ? '#F39C12' : '#E74C3C';
        }
        
        if (suggestionsElement) {
            suggestionsElement.innerHTML = analysis.suggestions.map(suggestion => 
                `<li>${suggestion}</li>`
            ).join('');
        }
    }

    // Template Data Loading
    loadTemplateData() {
        // Initialize with sample data for demonstration
        this.resumeData = {
            personal: {
                firstName: 'John',
                lastName: 'Doe',
                email: 'john.doe@email.com',
                phone: '(555) 123-4567',
                title: 'Software Developer'
            },
            experience: [
                {
                    title: 'Senior Developer',
                    company: 'Tech Company',
                    dates: '2020 - Present',
                    description: 'Led development of web applications using modern frameworks.'
                }
            ],
            education: [
                {
                    degree: 'Bachelor of Science',
                    school: 'University Name',
                    year: '2019'
                }
            ],
            skills: ['JavaScript', 'React', 'Node.js', 'Python'],
            summary: 'Experienced software developer with a passion for creating innovative solutions.'
        };
        
        this.updatePreview();
    }
}

// Initialize the resume builder when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.resumeBuilder = new ResumeBuilder();
});

// Template Gallery Management
class TemplateGallery {
    constructor() {
        this.templates = this.generateTemplateData();
        this.currentFilter = 'all';
        this.init();
    }

    init() {
        this.renderTemplates();
        this.setupFilters();
    }

    generateTemplateData() {
        const categories = ['professional', 'creative', 'modern', 'simple', 'ats-friendly'];
        const templates = [];
        
        for (let i = 1; i <= 200; i++) {
            templates.push({
                id: i,
                name: `Template ${i}`,
                category: categories[Math.floor(Math.random() * categories.length)],
                popularity: Math.floor(Math.random() * 100),
                preview: `https://picsum.photos/300/400?random=${i}`,
                colors: this.generateRandomColors()
            });
        }
        
        return templates;
    }

    generateRandomColors() {
        const colorPalettes = [
            ['#2C3E50', '#16A085', '#FEFEFE'],
            ['#6C5CE7', '#00B894', '#FEFEFE'],
            ['#E84393', '#0984E3', '#FEFEFE'],
            ['#2D3436', '#636E72', '#FEFEFE'],
            ['#F39C12', '#E67E22', '#FEFEFE']
        ];
        return colorPalettes[Math.floor(Math.random() * colorPalettes.length)];
    }

    renderTemplates() {
        const container = document.getElementById('template-grid');
        if (!container) return;

        const filteredTemplates = this.currentFilter === 'all' 
            ? this.templates 
            : this.templates.filter(t => t.category === this.currentFilter);

        container.innerHTML = filteredTemplates.map(template => `
            <div class="template-card" data-template="${template.id}" style="
                background: white;
                border-radius: 12px;
                overflow: hidden;
                box-shadow: 0 4px 12px rgba(0,0,0,0.1);
                transition: transform 0.3s ease, box-shadow 0.3s ease;
                cursor: pointer;
            ">
                <div class="template-preview" style="
                    height: 200px;
                    background: linear-gradient(135deg, ${template.colors[0]}, ${template.colors[1]});
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    color: white;
                    font-size: 24px;
                    font-weight: bold;
                ">
                    ${template.name}
                </div>
                <div class="template-info" style="padding: 20px;">
                    <h3 style="margin: 0 0 10px 0; color: ${template.colors[0]};">${template.name}</h3>
                    <p style="margin: 0; color: #666; font-size: 14px;">
                        ${template.category} • Popularity: ${template.popularity}%
                    </p>
                </div>
            </div>
        `).join('');

        // Add hover effects
        document.querySelectorAll('.template-card').forEach(card => {
            card.addEventListener('mouseenter', () => {
                card.style.transform = 'translateY(-8px)';
                card.style.boxShadow = '0 12px 24px rgba(0,0,0,0.15)';
            });
            
            card.addEventListener('mouseleave', () => {
                card.style.transform = 'translateY(0)';
                card.style.boxShadow = '0 4px 12px rgba(0,0,0,0.1)';
            });
        });
    }

    setupFilters() {
        document.addEventListener('click', (e) => {
            if (e.target.matches('.filter-btn')) {
                const filter = e.target.dataset.filter;
                this.currentFilter = filter;
                this.renderTemplates();
                
                // Update active state
                document.querySelectorAll('.filter-btn').forEach(btn => {
                    btn.classList.remove('active');
                });
                e.target.classList.add('active');
            }
        });
    }
}

// Initialize template gallery when needed
document.addEventListener('DOMContentLoaded', () => {
    if (document.getElementById('template-grid')) {
        window.templateGallery = new TemplateGallery();
    }
});